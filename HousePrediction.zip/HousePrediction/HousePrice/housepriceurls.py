from django.urls import path
from . import views
urlpatterns=[
    path('',views.Home,),
    path('',views.Predict),
    path('Predict/',views.Predict),
    path('Predict/result/',views.result),
]